from pathlib import Path
import subprocess,json,hashlib,datetime,sys
repo=Path('/tmp/thegn-maintenance-07-combined-20260915');source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();cg=Path('/proc/self/cgroup').read_text().strip().split('::',1)[1];assert Path('/sys/fs/cgroup'+cg+'/cpu.max').read_text().strip()=='100000 100000'
label=sys.argv[1];out=Path('/tmp/thegn-maintenance09-delivery-'+label+'-20260915.json');assert not out.exists()
r={'source':source,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'includes_staged_delivery_docs':True,'cpu_max':'100000 100000','checks':[]}
files=subprocess.check_output(['git','diff','--name-only','4ba63f55',source,'--','*.rs'],cwd=repo,text=True).splitlines()
for name,cmd in [('format',['rustfmt','--edition','2024','--check',*files]),('ratchets',['just','ratchets']),('spec',['just','openspec-validate']),('diff',['git','diff','--cached','--check','--','.',':(exclude)docs/audits/maintenance09-2026-09-15/**'])]:
 log=Path('/tmp/thegn-maintenance09-delivery-'+label+'-'+name+'-20260915.log')
 with log.open('wb') as f:res=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit_code':res.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};r['checks'].append(row);out.write_text(json.dumps(r,indent=2)+'\n');print(name,res.returncode,flush=True)
raise SystemExit(any(x['exit_code'] for x in r['checks']))
