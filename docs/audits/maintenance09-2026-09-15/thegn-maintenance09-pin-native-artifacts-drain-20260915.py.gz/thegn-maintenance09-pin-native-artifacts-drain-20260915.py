import datetime,hashlib,json,shutil,subprocess
from pathlib import Path
repo=Path('/tmp/thegn-maintenance-07-combined-20260915')
build=json.loads(Path('/tmp/thegn-maintenance09-native-drain-20260915.json').read_text())
assert build['exit_code']==0
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==build['source']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
messages=Path(build['messages'])
assert hashlib.sha256(messages.read_bytes()).hexdigest()==build['messages_sha256']
destination=Path('/tmp/thegn-maintenance09-native-drain-binaries-20260915')
assert not destination.exists()
artifacts={}
for line in messages.read_text().splitlines():
 try: message=json.loads(line)
 except json.JSONDecodeError: continue
 if message.get('reason')!='compiler-artifact' or not message.get('executable') or not message.get('profile',{}).get('test'):continue
 target=message['target']; label={'thegn_svc':'svc','thegn':'host'}.get(target['name'])
 if label is None:continue
 assert label not in artifacts
 manifest=repo/'crates'/('thegn-'+label)
 assert message['package_id'].startswith('path+file://'+str(manifest)+'#')
 binary=Path(message['executable']); depfile=binary.with_suffix('.d')
 assert depfile.exists()
 body=depfile.read_text()
 assert 'CARGO_MANIFEST_DIR='+str(manifest) in body
 assert str(manifest.relative_to(repo)/'src') in body
 artifacts[label]={'binary':binary,'depfile':depfile,'message':message,'manifest':manifest}
assert set(artifacts)=={'svc'}
destination.mkdir(mode=0o700)
r={'source':build['source'],'exit_code':0,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'build_receipt':'/tmp/thegn-maintenance09-native-drain-20260915.json','artifacts':{}}
for label,a in artifacts.items():
 binary=destination/(label+'-tests');depfile=destination/(label+'-tests.d')
 shutil.copy2(a['binary'],binary);shutil.copy2(a['depfile'],depfile)
 r['artifacts'][label]={'path':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'depfile_sha256':hashlib.sha256(depfile.read_bytes()).hexdigest(),'compiler_artifact_fresh':a['message']['fresh'],'manifest_dir':str(a['manifest']),'package_id':a['message']['package_id']}
out=Path('/tmp/thegn-maintenance09-native-drain-artifact-admission-20260915.json');assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
