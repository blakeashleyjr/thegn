# THE-325 drain independent review

- Date: 2026-09-15
- Candidate: c124a8f9b352cc0cae1c12e727bf9060e7770df9
- Comparison base: 4ba63f55cde2f30bcc6dc8291974ac929cceb67b
- Candidate checkout: /tmp/thegn-THE325-impl-luna-20260915
- Scope: partial direct-share credential/output slice only
- Review mode: source/evidence only; no edits, builds, tests, provider calls, DB, native execution, or Linear writes

## Verdict

**HOLD for the c124 candidate as a complete production change. APPROVE a separately extracted drain/debug slice after the two small reader corrections below.**

The candidate changes provider authentication and process environment before THE-328 custody exists:

- share/mod.rs:250-263 refuses every configured Bore secret except an absent default reference and refuses secret-bearing extra arguments. This removes the shipped Bore argv/ambient-secret behavior.
- share/mod.rs:305-424 resolves FRP tokens but marks token plans as requiring private materialization; start_with_env:774-779 then refuses them. Configured FRP shares therefore stop working until THE-328 is present.
- start_with_env:787-795 calls env_clear and passes only a small allowlist. This is a new environment contract and is coupled to the Bore refusal. It must not be extracted as part of the independent drain fix: preserving configured FRP/Bore behavior requires retaining the current provider-auth/environment path until the protected materialization and selected-runtime contracts land.
- materialize_files:1037-1050 remains create_dir_all, std::fs::write, and best-effort permission restriction. It does not provide THE-328 private credential custody.

This is a functional regression for configured secrets, even though the new refusal is fail-closed from a security perspective. The full candidate also contains the combined THE-321/322/other maintenance tree relative to 4ba, so it is not a clean standalone THE-325 patch.

## Smallest independently useful extraction

On root's clean maintenance09-drain checkout, extract only these hunks from share/mod.rs and their adapted tests:

1. Manual redacted Debug implementations for UrlRule, SharePlan, and RunningShare. Keep SharePlanFile's existing redaction. Adapt constructors to the base SharePlan shape; do not add requires_private_materialization or SecretValue as part of this extraction.
2. The bounded reader path: fixed-size scratch buffer, bounded diagnostic sync queue, one-entry priority URL channel, EOF-tail emission, and continued pipe draining after start returns. Keep the baseline provider builders, materialize_files, environment inheritance, and child cleanup unchanged.
3. The matching compact tests, adapted to the base API:
   - start_keeps_draining_so_child_survives_post_return
   - start_with_env_returns_late_url_from_eof
   - bounded_reader_keeps_unterminated_url_line_at_eof
   - bounded_reader_prioritizes_late_url_over_full_diagnostic_queue
   - bounded_lossy_output_stays_within_byte_limit
   - plan_and_running_share_debug_redact_args_and_public_address

Before warm compilation, make these two correctness corrections in the extracted reader:

- In drain_reader, retry std::io::ErrorKind::Interrupted rather than treating it as terminal. The current c124 Err(_) => return can close a pipe during a transient interrupted read and reintroduce child SIGPIPE/early-disconnect behavior.
- In start_with_env's RecvTimeoutError::Disconnected arm, perform one final url_rx.try_recv() before aborting the child. A URL can be emitted after the diagnostic sender disconnects but before the receiver observes it; current c124:875-878 can incorrectly report “exited before reporting a URL.”

The existing bounded queue uses nonblocking try_send, so diagnostic pressure does not stop pipe consumption. The URL channel remains bounded and independent. The 4096-byte limit bounds both scratch input and lossy UTF-8 output; oversized lines are discarded and therefore cannot be URL discovery inputs.

Do not extract env_clear/direct_client_env, Bore secret refusal, FRP requires_private_materialization, SecretValue builder changes, or materialize_files changes. These either break configured secrets or claim THE-328 work that is not present.

## Existing meaningful test evidence

The candidate tests directly cover the proposed extraction's behavior: post-return pipe draining with a finite child, unterminated URL-at-EOF, URL priority when the diagnostic queue is full, bounded invalid UTF-8 conversion, and Debug redaction. The production-start fixtures use an explicit PATH because the candidate environment path is cleared; that fixture detail must be removed or adapted when preserving baseline environment inheritance. Add one small reader seam test for an Interrupted read followed by a URL/EOF, and one regression test for the final URL-channel recheck if the warm patch introduces a helper seam.

No test here proves configured Bore/FRP compatibility after the candidate's environment/auth changes; those changes are explicitly excluded from the safe extraction.

## THE-327 and THE-328 disposition

THE-327 remains plan-only. Its v2 caller plan requires positive process/sidecar settlement before generation retirement, pre-effect DB reservation, bounded restore reads, and selected THE-330 runtime attestation. None of those caller integrations is present in this THE-325 candidate.

THE-328 remains a hard dependency for token-bearing FRP materialization. The candidate's refusal avoids writing a token through the old path, but it is not a shippable replacement for configured FRP behavior. Do not mark either issue complete or use the candidate to claim private credential custody.

THE-325 itself remains partial after the safe extraction: direct process output bounds and Debug redaction can land independently; protected credential materialization, Tailscale selected-runtime environment, and their native gates remain pending.

## Frozen source hashes

- Candidate share/mod.rs: be74c663516867a7514d61ccfdc85b9c78c7c0456548fde943d68a43e4181b6a
- Candidate share/tests.rs: f7f8e6a493c96eb672dc43d57ce52322b1d000a73974c8bdfee5dd1152009bbd
- Candidate commit: c124a8f9b352cc0cae1c12e727bf9060e7770df9
- Base commit: 4ba63f55cde2f30bcc6dc8291974ac929cceb67b

The candidate checkout had only the expected pre-existing modification to share/mod.rs while this review was performed.
