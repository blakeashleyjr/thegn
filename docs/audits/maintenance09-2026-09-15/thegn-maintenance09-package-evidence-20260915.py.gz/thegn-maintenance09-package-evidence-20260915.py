from pathlib import Path
import json,hashlib,gzip,subprocess,datetime
repo=Path('/tmp/thegn-maintenance-07-combined-20260915')
source='e72d7fcec31224dd9aa463743bc0f370d09770ba'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
focused=json.loads(Path('/tmp/thegn-maintenance09-focused-native-drain-receipt-20260915.json').read_text())
assert focused['source']==source and focused['failed']==0 and focused['passed']>0
for phase in ['clippy','native']:
 r=json.loads(Path('/tmp/thegn-maintenance09-'+phase+'-drain-20260915.json').read_text());assert r['source']==source and r['exit_code']==0 and r['cpu_max']=='100000 100000'
base=repo/'docs/audits/maintenance09-2026-09-15';assert not base.exists();base.mkdir()
patterns=['thegn-maintenance09-*.json','thegn-maintenance09-*.md','thegn-maintenance09-*.py','thegn-maintenance09-*.log','thegn-maintenance09-*.jsonl','thegn-THE220-drain-independent-luna-20260915.*','thegn-THE324-drain-independent-luna-20260915.*','thegn-THE325-drain-independent-luna-20260915.*','thegn-THE325-drain-implementation-luna-20260915.*']
files={p for pattern in patterns for p in Path('/tmp').glob(pattern) if p.is_file()}
artifacts=[]
for p in sorted(files):
 if 'checkpoint' in p.name:continue
 raw=p.read_bytes();data=gzip.compress(raw,mtime=0);name=p.name+'.gz';(base/name).write_bytes(data)
 artifacts.append({'file':name,'sha256':hashlib.sha256(data).hexdigest(),'payload_sha256':hashlib.sha256(raw).hexdigest(),'encoding':'gzip'})
source_hashes={f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in ['crates/thegn-svc/src/share/mod.rs','crates/thegn-svc/src/share/tests.rs']}
manifest={'source':source,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'THE-325 bounded output and redaction only; full issue remains open','native_passed':focused['passed'],'source_hashes':source_hashes,'artifacts':artifacts}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(repo/'docs/audits/maintenance09-2026-09-15.md').write_text(f'''# Maintenance queue drain — 2026-09-15

Source `{source}` delivers the bounded output and diagnostic portion of
THE-325. Existing tunnel clients retain their authentication, environment,
file materialization, and provider configuration behavior. No new issue was
admitted after the user's drain instruction.

## Delivered behavior and evidence

Provider lines have a 4096-byte input and encoded-output limit. Oversized lines
are discarded through newline. Diagnostic buffering has 64 entries and URL
discovery has a separate one-entry signal. Readers retry interrupted reads,
preserve unterminated EOF addresses, recheck the address before reporting
diagnostic disconnection, and continue draining after startup returns.
Plan arguments/environment values, URL-rule values and public addresses are
redacted from Debug. Early-exit errors omit raw provider output. On startup
disconnection the owned parent is killed before waiting; this is not a
process-tree settlement or bounded reaper guarantee.

Primary and independent source/delta reviews approved the patch. Scoped strict
Clippy passed. One warm service test harness compilation used one job, disabled
sccache and a verified one-CPU quota. All **{focused['passed']} selected share tests
passed** in isolated temporary XDG state with one test thread. These cover
provider plans/configuration plus interrupted/oversized reads, full queues,
EOF startup, redaction, and continued pipe draining. No live provider, live
database, host restart, release build or performance measurement was performed.
The native runner is not a hostile hung-descendant cleanup proof.

[Evidence manifest](maintenance09-2026-09-15/manifest.json) records exact source
and artifact hashes. Raw evidence is stored losslessly as gzip to preserve
historical output without treating it as authored source. Final delivery gates
are added alongside the manifest before landing.

## Work held outside main

| Issue | Disposition |
|---|---|
| THE-220 | Claim APIs, host/process custody and schema integration remain unfinished. Clock correction has no standalone production caller. |
| THE-324 | Authority owner, writer/recovery, consumers and schema upgrade/verifier integration remain unfinished. |
| THE-327 | Lease/manifest substrate remains unwired; generation retirement needs positive settlement, selected runtime and conditional DB reservation. |
| THE-328 | Protected credential materialization remains dependent on unfinished custody/lifecycle integration. |
| THE-325 remainder | Credential transport, environment admission and selected-runtime/custody integration remain open. The full candidate would disable configured authentication and was not merged. |
| THE-319, THE-330 | Admitted before the freeze; no implementation entered this delivery. Further investigation stopped for the drain. |
| THE-630, THE-631, THE-632 | Performance evidence remains HOLD; the candidate regressed measured timings. No repeat-to-green or new performance build. |

THE-220, THE-324, THE-325 and THE-327 private candidates are preserved in local
`maintenance-held-20260915-the-*` branches, with exact refs/commits in the held
branch receipt. Held work is not merged, fixed, or marked Done. Completed
THE-321/THE-322 and the earlier maintenance batches remain on main.

This closes the reviewable merge queue for the requested rebuild; it does not
close all outstanding Linear issues. No push or live application restart is
part of this delivery. The user's dirty justfile and original untracked audit
files must be verified unchanged before and after the local fast-forward.
''')
tasks=repo/'openspec/changes/bound-public-share-output/tasks.md';tasks.write_text(tasks.read_text().replace('- [ ]','- [x]'))
p=repo/'delivery/index.json';data=json.loads(p.read_text())
entry=next(e for e in data['entries'] if e['change']=='bound-public-share-output');entry.update(lifecycle='delivered-awaiting-archive',delivered_at='2026-09-15',summary='Bounded public-share output and redacted diagnostics passed scoped strict lint and '+str(focused['passed'])+' isolated share tests. This subtask is delivered; full THE-325 credential isolation remains open.')
p.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'artifacts':len(artifacts),'native_passed':focused['passed'],'source':source}))
