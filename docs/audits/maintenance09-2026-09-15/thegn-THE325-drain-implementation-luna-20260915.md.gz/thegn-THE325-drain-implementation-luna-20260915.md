# THE-325 bounded share drain implementation

Date: 2026-09-15
Candidate: `37083cf9c2e4408ea03d9fa1cbb6d2f4bedf64c0`
Base: `4ba63f55cde2f30bcc6dc8291974ac929cceb67b`
Checkout: `/tmp/thegn-THE325-drain-luna-20260915`

## Scope and verdict

This is a bounded, source-only extraction approved for independent review. It changes only `crates/thegn-svc/src/share/mod.rs` and `crates/thegn-svc/src/share/tests.rs`.

The patch bounds each reader's line scratch space at 4096 bytes, uses a 64-entry nonblocking diagnostic queue, and gives URL discovery its own one-entry priority channel. Readers continue draining after `start` returns. Unterminated EOF lines are emitted, `Interrupted` reads retry, and the startup disconnect path checks the priority URL signal once more before reporting failure. Debug output redacts plan arguments/environment values, URL-rule values, and `RunningShare.public_url`; early startup errors no longer include collected provider output.

Provider plan signatures and fields, Bore/FRP credential expansion and argv/file behavior, inherited child environment, materialization, and the existing best-effort child cleanup remain in place. The patch deliberately does not import the candidate's `.env_clear` allowlist, Bore-auth refusal, FRP private-materialization gate, `SecretValue` changes, or THE-328 custody implementation.

Full THE-325 remains open pending protected credential materialization and the separately owned process/runtime work. This slice does not claim process-tree settlement: `abort_child` remains best-effort kill/wait for terminal startup failure, and THE-331 owns broader lifecycle guarantees.

## Tests added or retained

The existing finite post-return child-drain fixture remains in `share/tests.rs`. Added fixtures cover:

- URL extraction from an unterminated provider line at EOF;
- retry after one `ErrorKind::Interrupted` read;
- discard of an oversized line while retaining a following URL;
- delivery of the priority URL after the diagnostic receiver is gone;
- bounded redacted `SharePlan` Debug output;
- shipping `start` early-exit errors that omit provider diagnostic secrets.

No Cargo build, test execution, native execution, provider call, DB action, Linear action, or canonical checkout edit was performed. `rustfmt` and `git diff --check` passed.

## Residual ownership

THE-327 remains a plan/integration concern around lease admission and positive settlement. THE-328 remains the dependency for private credential files; this patch preserves current materialization behavior so configured Bore/FRP paths are not refused or silently changed by the bounded reader extraction. Tailscale/OCI runtime selection and THE-331 process ownership are outside this slice.

## Source hashes

- `crates/thegn-svc/src/share/mod.rs`: `f491a7e2cf7624bd055d58fd488fba0dcbb23ff4a9956924a22bc33c8d181757`
- `crates/thegn-svc/src/share/tests.rs`: `c8734d51831d3ee05bd0d3a739691db2d4a13d1fb97f9b2b5cf20e1c3a4b22df`
