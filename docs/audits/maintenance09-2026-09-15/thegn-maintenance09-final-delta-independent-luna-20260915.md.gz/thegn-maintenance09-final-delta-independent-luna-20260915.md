# Maintenance09 final THE325 delta review — Luna high

Date: 2026-09-15

Reviewed integration `/tmp/thegn-maintenance-07-combined-20260915` at
`e72d7fcec31224dd9aa463743bc0f370d09770ba` (tree
`899dec162d286de42549368557711439d7e999f8`), based on maintenance08
`4ba63f55cde2f30bcc6dc8291974ac929cceb67b`.

## Verdict

Approve the final source and documentation delta for the bounded THE325
public-share output slice, pending root's planned compiled/native gates.
Production `crates/thegn-svc/src/share/mod.rs` is byte-identical to the
independently reviewed frozen extraction from commit `37083cf9c2e4408ea03d9fa1cbb6d2f4bedf64c0`.

The final test delta restores the two meaningful queue/byte-bound checks:
late URL discovery remains available after a full 64-entry diagnostic queue,
and lossy UTF-8 output remains within the 4096-byte bound. It also adds a
`RunningShare` debug assertion to the existing EOF URL fixture, proving the
public URL is omitted from debug output while the runtime URL remains usable.
These complement the previously reviewed interrupted-read, oversized-line,
disconnected-diagnostic, EOF, and early-error-redaction fixtures.

The `bound-public-share-output` OpenSpec delta accurately describes this as a
partial residual split. It records bounded lines/queues, URL priority, EOF
handling, continued draining, and redaction, while explicitly leaving
credential transport, environment admission, state-file custody, sidecar
identity, and process-tree settlement unfinished. Delivery metadata marks the
change active and residual-split, with no false issue closure.

## Scope and limits

No authentication, provider environment, configured-secret refusal, state-file
custody, sidecar identity, or process-tree guarantee was introduced by this
delta. No Cargo, build, test, native/provider, live database, Linear, or
canonical mutation operation was performed.

Exact hashes:

- `crates/thegn-svc/src/share/mod.rs`: `f491a7e2cf7624bd055d58fd488fba0dcbb23ff4a9956924a22bc33c8d181757`
- `crates/thegn-svc/src/share/tests.rs`: `6084e15209495abe617f3e6b5e5cdfcba4954a2942cc4fe15817ac76178f209e`
- `openspec/changes/bound-public-share-output/design.md`: `c6d75ad6c13d3dc3ea3fe6ad63aed7874629aa74d2c9f866804d6d4ef970fea0`
- `openspec/changes/bound-public-share-output/proposal.md`: `09d7594e3462f3da6c2e54d0be0826ea9c2f15008a0e71156f8a449db7c81e72`
- `openspec/changes/bound-public-share-output/tasks.md`: `fa13947f5ee49f7760a09e235a7c8485e92d5b24dc84fe3ea3c1f1ba1e5886e0`
- `openspec/changes/bound-public-share-output/specs/public-share/spec.md`: `9d2935d7e7e56916f95355e9b5255f1cf82634eaea421895579a3e2f3d1d8564`
- `delivery/index.json`: `a30956c53a509c84663392b058cc49dc6664a36dc02926a1487782f931bb1400`
- `delivery/issues.json`: `ba4e82d95c8e92d7672bd41c8409145ee7e24d4fba0ab76bfcde59b32980032a`
