from pathlib import Path
import subprocess,json,hashlib,datetime,gzip
repo=Path('/home/blake/code/thegn');candidate=Path('/tmp/thegn-maintenance-07-combined-20260915');base='4ba63f55cde2f30bcc6dc8291974ac929cceb67b';source='e72d7fcec31224dd9aa463743bc0f370d09770ba'
def git(cwd,*args):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
head=git(candidate,'rev-parse','HEAD');assert head!=source;assert not git(candidate,'status','--porcelain');assert git(repo,'branch','--show-current')=='main';assert git(repo,'rev-parse','HEAD')==base
approval=json.loads(Path('/tmp/thegn-maintenance09-primary-final-approval-20260915.json').read_text());assert approval['decision']=='approved for local main' and approval['source']==source
for path,h in approval['review_hashes'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h,path
original=json.loads(Path('/tmp/thegn-THE621-canonical-prelanding-preservation-20260914.json').read_text())
def preserved():
 assert hashlib.sha256((repo/'justfile').read_bytes()).hexdigest()==original['justfile_sha256']
 for f,h in original['untracked'].items():assert (repo/f).exists() and hashlib.sha256((repo/f).read_bytes()).hexdigest()==h,f
preserved();changed=git(candidate,'diff','--name-only',source,head).splitlines();assert all(f.startswith('docs/audits/') or f=='delivery/index.json' or f=='openspec/changes/bound-public-share-output/tasks.md' for f in changed),changed
manifest=json.loads((candidate/'docs/audits/maintenance09-2026-09-15/manifest.json').read_text());assert manifest['source']==source
for row in manifest['artifacts']:
 raw=(candidate/'docs/audits/maintenance09-2026-09-15'/row['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
 if row.get('encoding')=='gzip':assert hashlib.sha256(gzip.decompress(raw)).hexdigest()==row['payload_sha256']
for f,h in manifest['source_hashes'].items():assert hashlib.sha256((candidate/f).read_bytes()).hexdigest()==h
receipt=Path('/tmp/thegn-maintenance09-local-main-landing-receipt-20260915.json');assert not receipt.exists()
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_head':base,'delivery':head,'tested_source':source,'native_share_tests_passed':35,'user_justfile_sha256':original['justfile_sha256'],'user_untracked_preserved':len(original['untracked']),'status':'prelanding verified','push':False,'live_restart':False};receipt.write_text(json.dumps(r,indent=2)+'\n')
subprocess.run(['git','fetch',str(candidate),'maintenance09-drain'],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
subprocess.run(['git','-c','core.hooksPath=/dev/null','merge','--ff-only','FETCH_HEAD'],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert git(repo,'rev-parse','HEAD')==head;preserved()
for f,h in manifest['source_hashes'].items():assert hashlib.sha256((repo/f).read_bytes()).hexdigest()==h
r.update(status='local-main fast-forward complete',finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),new_head=git(repo,'rev-parse','HEAD'));receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
