# THE-324 independent drain review — Luna high

Date: 2026-09-15  
Candidate: `/tmp/thegn-THE324-impl-luna-20260915`  
Frozen commit: `0f35f06ee851d631b281eb6a2d1377c0d669d402`  
Frozen tree: `b34011f6d860a7cdf4f604abb6f5bf6c6ba8cb4c`  
Baseline: `fadd7164ce46b684e1e23ee2174aa876fc619d42`

## Verdict

**Hold the full THE-324 candidate.** The source-only slice is a useful,
bounded custody and identity substrate, but it is not production-mergeable as
the completed tracker identity change. The authority owner, writer wiring,
consumer migration, and schema upgrade integration remain absent. No landing
approval is given for the full candidate.

## Evidence and positive scope

I read the frozen diff, the existing shared-seam report, the THE-324 OpenSpec
proposal/design/tasks, and production callsites. The host `gate_path` adapter
retains the old Directory/Lock/Regular/read API while the implementation is
centralized in core `fs_custody.rs`. That seam has retained descriptor,
no-follow, identity-recheck, private-mode, and nonblocking-lock behavior. The
lossless source-key v3 encoding and the `ConfigSourceLock` delegation are
source-visible and coherent within this slice.

The identity tests cover bounded reconciliation, source separation, explicit
and legacy IDs, restart/rename/rotation, retirement, stale publication, and
batch limits. The OpenSpec tasks correctly leave owner/writer and consumer
wiring unchecked. These are bounded source claims only; I did not run Cargo,
tests, native/provider code, a live database, or UI/Linear operations.

## Blockers to production merge

1. **The authority substrate is dormant.** `db_issue_identity.rs` exposes
   observation/publication methods, but searches found no production caller
   outside its own tests/module. `ConfigSourceLock::try_acquire` in
   `issue_identity.rs:161-183` is likewise not acquired by the real layered
   config owner/reload path. The normal writers in `config_write.rs:44-83`
   still read and atomically rename the pathname without retaining or
   verifying a source lock. Onboarding and secret/config callsites continue
   through the legacy writer API (`thegn-host/src/handlers/onboarding.rs:250-261`;
   `config_write.rs:332-355,398-405`). This leaves the journal unconnected to
   the source observation and publication authority it is meant to protect.

2. **The returned identity is not enforced by consumers.** `IssueAccount`
   now carries optional `instance_id`, but provider hydration, cache storage,
   daemon issue operations, calendar paths, and UI/autopilot-facing paths
   still use provider plus display/account name. For example,
   `thegn-host/src/hydrate_tracker.rs:62-123` and
   `thegn-core/src/store/cache.rs:64-78` retain `(repo, provider, account)`
   keys, while the provider/dispatch paths do not consume `instance_id`.
   `upsert_issue_account_with_instance_id` is only exercised by its own test;
   legacy production writers never establish or reconcile the durable
   instance. Merging this slice would therefore advertise identity metadata
   without binding requests or caches to it.

3. **Schema v69 is not integrated as a versioned upgrade.** `db.rs:1653-1679`
   adds the two tracker tables to the broad schema batch and
   `db.rs:2071-2072` stamps version 69. The migration sequence at
   `db.rs:2008-2021` still ends at v68 and has no v69 migration or verifier in
   `db_migrate.rs`. A fresh/full initialization can create the tables, so this
   review does not claim they are absent there; the blocker is the missing
   explicit upgrade/verification contract for existing databases and the lack
   of a real reader/writer owner. This requires coordination with the
   migration owner before landing.

4. **THE-327 share-state code is not a shipped consumer.** `share_state.rs:1-6`
   explicitly says it is not wired into the share supervisor. The actual host
   supervisor continues through the legacy `share::share_state_dir` path
   (`thegn-host/src/share.rs:353-368`), and no production references to
   `ShareLease` or `share_state` were found. It is an incomplete identity,
   manifest, and lease slice, not evidence of THE-327 share lifecycle
   integration.

## THE-327 shared-custody extraction

The extraction has a real technical benefit: it gives core
`ConfigSourceLock` and future share/config consumers one descriptor-relative
no-follow custody implementation, while the host adapter preserves existing
gate callsites. It is separately reviewable as a compatibility-preserving
seam after compiled and platform gates.

It should be held with the THE-324 integration rather than landed solely to
justify the currently unused identity/share APIs. The useful landing unit
needs at least a real source-owner/writer consumer, migration/upgrade
verification, and the required cross-platform/compiled evidence. The
`share_state.rs` lease layer should remain out of a production completion
claim until the share supervisor and both RunningShare consumers actually use
it; its private custody policy must not be substituted for the host gate's
existing policy.

## Exact source evidence

The following hashes are from the frozen checkout:

| File | SHA-256 |
|---|---|
| `crates/thegn-core/src/config_issues.rs` | `ed5796f82914440be6785bbcba5a57013fec3810be813c2285deac382640d122` |
| `crates/thegn-core/src/config_write.rs` | `8cfe49390fb6a4694618f8e269ec8b1def134a7477661b26b532695057bda8f0` |
| `crates/thegn-core/src/db.rs` | `d2ae13fffa949a54c74329ea301421866f9ea064a4b9879d4a8ca447ed3a120c` |
| `crates/thegn-core/src/db_issue_identity.rs` | `4ad65c5ad5f498ccb76a2a58094495724e357c03f00bcbfd3221769d9621f46b` |
| `crates/thegn-core/src/fs_custody.rs` | `ca9f0fc9f5d640cca038f65f43844594e1bdf05d9c5869ef727e5bacc2b8f301` |
| `crates/thegn-core/src/issue_identity.rs` | `f02219d07c3fddc83e750f009a909d7f12fe6652df2ede54e1d771f27f117613` |
| `crates/thegn-core/src/lib.rs` | `4d8d92fe4dc8124a364df543c11490cf17a8cac42458aaf1a3a145608ba494c5` |
| `crates/thegn-core/src/share_state.rs` | `ce9d41431a5cfde8e34bf13e43baad7bdd475a2dc2a38e4da61406e60cde4b8e` |
| `crates/thegn-host/src/platform/gate_path.rs` | `2c3bf8a1515181b9397d207cad84ef6e81290b48d49aa4c9959abcabc83c9144` |
| `delivery/index.json` | `c3ffa2fb2143d9178619de85c838f47cfed542bc817e7b59c81890cc97631391` |
| `delivery/issues.json` | `93cd39b6b05fba2a1f2c9f159cabc8aed3120cb36dc060794053a5dcd1087cdd` |
| `openspec/changes/bind-tracker-account-identity/tasks.md` | `3da00db9eea976f6eef4e756ae31d89a1634f78060613c34c78ebce0f479c275` |

No files in the candidate were modified by this review.
