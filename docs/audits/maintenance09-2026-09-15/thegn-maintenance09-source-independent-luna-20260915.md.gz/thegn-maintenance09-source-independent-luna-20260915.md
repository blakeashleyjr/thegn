# Maintenance09 THE325 drain source review — Luna high

Date: 2026-09-15

Reviewed private drain extraction:
`/tmp/thegn-THE325-drain-luna-20260915` at commit
`37083cf9c2e4408ea03d9fa1cbb6d2f4bedf64c0`, tree
`c2641db3cf2a937c2dc09c67c8d03de32fa4781b`, parent maintenance08
`4ba63f55cde2f30bcc6dc8291974ac929cceb67b`.

## Verdict

Approve this two-file THE325 drain extraction for root's compiled gates. It is
bounded to existing share startup output and cleanup behavior. It does not
change authentication, provider environment admission, configured-secret
refusal, or process-tree guarantees.

## Verified behavior

- `start` uses a bounded `sync_channel(64)` for diagnostics and a separate
  one-entry URL priority channel, so noisy output cannot suppress URL discovery
  and reader threads never block indefinitely on a dropped receiver.
- `drain_reader` uses bounded byte chunks and a `4096`-byte line limit;
  oversized lines are discarded through newline, later lines remain usable, and
  lossy UTF-8 conversion is bounded before queueing.
- `Interrupted` reads retry. EOF emits a final unterminated line, allowing a
  valid URL in the tail to be recognized. A final priority-channel check runs
  after diagnostics disconnect.
- Early exit and timeout paths call `kill` before `wait`; the helper is clearly
  documented as terminal startup cleanup only and makes no process-tree claim.
- Generic error text no longer includes captured output. `UrlRule`, `SharePlan`,
  `SharePlanFile`, and `RunningShare` debug output redact markers, templates,
  args, environment values, file contents, and public URLs while retaining
  useful nonsecret shape.
- Existing post-return finite-child draining remains intact because readers
  continue consuming until stream EOF after `start` returns.

The added source fixtures cover interrupted reads, oversized-line recovery,
URL priority after a diagnostics receiver disappears, debug redaction, EOF URL
recognition, and early-exit diagnostic redaction.

## Limits and evidence

This review did not run Cargo, tests, builds, native/provider processes, or
modify canonical/main. The candidate is a private source checkout and root
owns compilation/native admission. The extraction provides no process-tree
settlement guarantee; that remains outside THE325's bounded drain scope.

Exact changed-file SHA-256 values:

- `crates/thegn-svc/src/share/mod.rs`: `f491a7e2cf7624bd055d58fd488fba0dcbb23ff4a9956924a22bc33c8d181757`
- `crates/thegn-svc/src/share/tests.rs`: `c8734d51831d3ee05bd0d3a739691db2d4a13d1fb97f9b2b5cf20e1c3a4b22df`

`git diff --check` passed for the frozen commit's parent-to-commit diff.
