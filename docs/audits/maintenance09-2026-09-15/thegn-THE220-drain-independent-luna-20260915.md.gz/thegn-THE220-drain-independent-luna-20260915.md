# THE-220 final drain disposition — Luna high

Date: 2026-09-15

## Reviewed source

I reviewed private checkout `/tmp/thegn-THE220-impl-luna-20260915` at
`301ac802095b03e74346f1f8a5b0bc4712b72597` (tree
`82fd2c12ecf1493cb3f2e169f744e1f89f7da468`), whose parent is the frozen
bounded claim revision `36b75b2fdc5c4b85aefc6d0433150bd02fbbdc91`.
The comparison drain source is maintenance08 `4ba63f55cde2f30bcc6dc8291974ac929cceb67b`
(tree `7987280cbd0d12c50411e3e15c24d28e6947123b`).

The reviewed commit moves the lease clock sample in `renew_merge_claim`,
`consume_merge_agent_attempt`, `update_merge_status_claimed`, and
`set_merge_target_claimed` until after `BEGIN IMMEDIATE` has acquired the
SQLite write lock. Its private clock fixtures hold a competing writer lock,
wait for the operation's busy callback, let the lease expire, release the
writer, and check that no late attempt, renewal, target, or status write is
accepted. The fixture also checks the unchanged attempt, target, and status
values.

## Disposition

There is no independently mergeable production fix in this commit for the
current drain. The four production changes are coherent within the preceding
THE-220 claim API, but that API is not present in maintenance08/main: its
`WorktreeAuxStore` has no claim admission, lease renewal, attempt-result,
status-fencing, or target-fencing methods, and its `db_aux.rs` has only the
legacy queue operations. Maintenance08 also has no THE-220 claim columns in
its schema path. Cherry-picking the commit would therefore have no valid
source context and cannot safely land only the clock changes without importing
the unfinished inactive claim contract and its unassigned schema migration.

The clock fixtures are useful evidence for the future combined THE-220 build,
but are not independently executable against the current drain. Their
multi-connection busy-handler handshake is source-reviewed only here; no test
or build was run in this review.

Safe drain status: hold the entire THE-220 candidate, including
`301ac802`, until the root combined integration assigns and applies the claim
schema migration, wires every queue mutation surface, and admits the complete
process/filesystem custody contract. Do not cherry-pick or partially land the
inactive API. The existing maintenance08 drain remains unchanged.

## Source evidence

Exact SHA-256 values at the reviewed commit:

- `crates/thegn-core/src/db_aux.rs`: `f900b1716b3f3ad4a7077f28b632aa7356ccf7a715efdf01f44d3bb7cb9be109`
- `crates/thegn-core/src/db_merge_claim_tests.rs`: `c3d2a6d59c8213471d5b5b05d7d8e78ec9db6cbc3cef97b08a92e3c13b3aae57`
- `crates/thegn-core/src/store/worktree_aux.rs`: `1d7b292920b0ff61ed27089b986c47ad8cb91e503d642569df2ab4d6ff826ed9`
- `crates/thegn-core/src/store/mod.rs`: `03cc8f5d889b2bd2e5a526668d58e510ee2fc7f87a43cb8961d76c524f429545`
- `crates/thegn-core/src/db.rs`: `dc207ca5076124ede38592bd17bd3e604506368cc24728694d740593e8782b52`
- `crates/thegn-core/src/db_migrate.rs`: `cdf79a5dcab0c9c753e31d8aaeadeb2859ecb3ab9c79a86ba02e447a400d8e7c`

No source, canonical, database, provider, Cargo, build, test, native, or
Linear operation was performed.
