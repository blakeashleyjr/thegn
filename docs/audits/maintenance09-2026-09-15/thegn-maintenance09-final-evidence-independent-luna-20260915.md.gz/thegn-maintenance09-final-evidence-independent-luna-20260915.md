# Maintenance09 final evidence review — Luna high

Date: 2026-09-15  
Reviewer: `luna_native_evidence`  
Source: `e72d7fcec31224dd9aa463743bc0f370d09770ba`  
Checkout: `/tmp/thegn-maintenance-07-combined-20260915`

## Verdict

**Accept the bounded maintenance09 evidence for the 35 selected share tests.**
This supports the scoped share output, URL, serialization, diagnostics, and
child-drain changes. It does not establish a full service test pass or full
credential-policy closure.

## Receipt verification

- Strict service Clippy with `control-grpc`, `--lib --tests`, one Cargo job,
  and the recorded 100% CPU cgroup completed with exit 0. Receipt:
  `/tmp/thegn-maintenance09-clippy-drain-20260915.json`; log SHA-256
  `f287452bb66f0b2a3724e5b5c47c4e558c0a20d90b0a5bc05d23355f01b7aad9`.
- The service test harness compile (`--lib --no-run`) completed with exit 0
  against the same source. Receipt:
  `/tmp/thegn-maintenance09-native-drain-20260915.json`; JSONL SHA-256
  `1479c6246b21edf61d7eab3d1c775fc17733580b63aee2ed04fe1d3fb26e575c`.
- Artifact admission records the expected service package and manifest,
  source-bearing depfile, and pinned test binary
  `/tmp/thegn-maintenance09-native-drain-binaries-20260915/svc-tests` with
  SHA-256 `1a579ce896971c7a614da9cc59d16d6c30f9bac9275479256429b8010537b1e8`.
  The compiler artifact is marked `fresh: false`; the source commit, package,
  manifest, depfile, and binary hashes provide the reviewed warm-cache
  provenance.
- The selected manifest contains exactly 35 `share::tests::` selectors. The
  focused receipt records `35` exact one-test passes and `0` failures; every
  test result line reports one passed, zero failed. Focused log SHA-256:
  `194c29cd39eabe4645c8d78d63f0f26c1fbf938383e882b3de08e21296e82b4c`.
- The existing isolated runner supplies temporary XDG directories, filtered
  environment, one test thread, and no live provider or DB access. The finite
  child-drain fixture passed in 2.31 seconds.

The evidence is limited to the selected 35 share tests and this exact source
artifact. No additional build or test was run for this review.
