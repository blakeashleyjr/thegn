# Maintenance09 validation-plan independent review — Luna high

Date: 2026-09-15  
Scope: source-only review of the maintenance09 build, artifact-pinning, matrix,
selection, and isolated-runner plans.

## Verdict

**Conditionally approved for the planned bounded gates after source freeze.**
The drivers pin the approved checkout and source, use one `thegn-svc` job with
`control-grpc`, set `CARGO_BUILD_JOBS=1`, disable the compiler wrapper, verify a
100% CPU cgroup quota, and preserve exact binary/depfile provenance. The
selection plan covers the complete `share::tests::` prefix and invokes each
selected test through the existing filtered-environment runner.

The previously noted evidence-overwrite gap is fixed. The build driver now
refuses any pre-existing receipt, log, or compiler JSONL path, and the matrix
driver refuses a pre-existing selected-manifest path as well as its focused
log/receipt. This preserves prior evidence across retries.

## Bounded coverage and isolation

The runner allocates private temporary XDG state/config/data/cache/runtime
directories, filters inherited environment to reviewed variables, runs one
test thread, and does not contact live providers or databases. The share test
prefix includes provider argument/config serialization, URL extraction,
invalid-field refusal, and the finite post-return pipe-draining child fixture.
The fixture’s shell child receives the preserved `PATH`; no process-global
secret environment is supplied by the runner.

Artifact admission checks the recorded source commit and clean checkout,
package/manifest identity, depfile manifest and source paths, executable
profile, and binary/depfile hashes. The matrix rechecks the binary hash and
requires every planned prefix to select at least one test before any run.

## Qualifications

The approval is gated on materializing the primary compile-approval JSON and
committing the currently dirty checkout before execution; the drivers’ source
and clean-tree assertions should refuse earlier states. This review does not
claim hostile hung-descendant cleanup: the external 30-second guard bounds a
test invocation, while selected finite fixtures normally reap their children.
No build, test, native execution, provider call, or script execution was
performed by this reviewer.

## Reviewed artifact hashes

- `build-driver-drain`: `d3ac6dac6611eed5f383311f942d4d0e4c0da1a10a64fc64d3cd3d734150001e`
- `pin-native-artifacts-drain`: `a8909bd11a2a2569b7ac58142ca384e6a31e32b488629007ee5857eb6328854b`
- `native-drain-matrix-driver`: `b29c8c492b92df32747483f78406a2f969333da58a11d8a7de1de51d67c60c93`
- `native-drain-selection-plan`: `e7efbdc379879c932ecc9598729aecd7d64427a6f60cf8dbf02d54945e72e471`
- `private-test-runner`: `6809313d9ce8fea04dcc7ad81d88e7b3ab09a41ec130155eff8514078ed3ea07`

No files were edited by this review.
