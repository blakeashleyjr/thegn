mod plugin { pub mod proc {pub const MAX_LINE_BYTES: usize = 1 << 20;} pub mod session { use std::time::Duration; use thegn_core::plugin_api::{RpcMessage,RpcResponse};pub const MAX_RESIDENT_SESSIONS: usize = 32;
pub const MAX_QUEUED_FRAMES: usize = 32;
pub const MAX_QUEUED_BYTES: usize = 2 * super::proc::MAX_LINE_BYTES;
pub const CLOSE_BUDGET: Duration = Duration::from_secs(2);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SessionFailure {
    Full,
    TooLarge,
    Closed,
}
impl std::fmt::Display for SessionFailure {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Self::Full => "resident admission is full",
            Self::TooLarge => "resident frame exceeds limits",
            Self::Closed => "resident session is closed",
        })
    }
}
impl std::error::Error for SessionFailure {}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CloseReason {
    WriterClosed,
    Requested,
    StdoutClosed,
    ProcessExit,
    Protocol,
    WriteFailed,
    WriteTimeout,
    CallbackPanic,
    OwnerPanic,
    Shutdown,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TreeGuarantee {
    Unproven,
}

/// Independent facts: leader reaping never certifies descendant containment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SessionOutcome {
    pub reason: CloseReason,
    pub leader_reaped: bool,
    pub code: Option<i32>,
    pub pipes_settled: bool,
    pub tree: TreeGuarantee,
    pub termination_requested: bool,
    pub errors: Vec<String>,
}
impl SessionOutcome {
    pub fn settled(&self) -> bool {
        self.leader_reaped && self.pipes_settled
    }
}
#[derive(Debug, Clone)]
pub enum SessionEvent {
    Message(RpcMessage),
    Response(RpcResponse),
    Junk(String),
    /// Last callback. The completion receipt carries reaping/pipe facts.
    Exit {
        code: Option<i32>,
    },
}
 #[path="/tmp/thegn-audit-maintenance-protocols-20260913/crates/thegn-svc/src/plugin/session/admission.rs"] pub mod admission; }}