use std::io::Write;
fn main() {
    let (_reader, mut writer) = std::os::unix::net::UnixStream::pair().unwrap();
    println!("std UnixStream write: {:?}", writer.write(&[1]));
}
