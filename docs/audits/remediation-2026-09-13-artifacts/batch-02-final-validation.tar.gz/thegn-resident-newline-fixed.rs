use std::io::{self, Write};
struct BoundedFrame(Vec<u8>, usize);

impl BoundedFrame {
    fn finish(mut self) -> Vec<u8> {
        // Serde may finish at a non-power-of-two capacity. An ordinary push
        // could double that allocation beyond the frame/remaining-byte cap.
        if self.0.len() == self.0.capacity() {
            self.0.reserve_exact(1);
        }
        self.0.push(b'\n');
        self.0
    }
}

impl Write for BoundedFrame {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        if bytes.len() > self.1.saturating_sub(self.0.len()) {
            return Err(io::Error::other("resident frame exceeds byte limit"));
        }
        // Vec's geometric growth must not exceed the explicit allocation cap.
        let needed = self.0.len() + bytes.len();
        if needed > self.0.capacity() {
            let capacity = needed
                .max(self.0.capacity().saturating_mul(2))
                .min(self.1 + 1);
            self.0.reserve_exact(capacity - self.0.len());
        }
        self.0.extend_from_slice(bytes);
        Ok(bytes.len())
    }
    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

fn main() {
 const LIMIT: usize = 1024*1024;
 let value=serde_json::json!({"id":1000000,"method":"provider.call","params":{"a":"x".repeat(300000),"b":"y".repeat(300044)}});
 let mut frame=BoundedFrame(Vec::new(),LIMIT-1);
 serde_json::to_writer(&mut frame,&value).unwrap();
 assert_eq!(frame.0.len(),600108);assert_eq!(frame.0.capacity(),600108);
 let frame=frame.finish();
 println!("wire_len={} capacity={} max={LIMIT}",frame.len(),frame.capacity());
 assert_eq!(frame.len(),600109);assert!(frame.capacity()<=LIMIT);
 assert_eq!(serde_json::from_slice::<serde_json::Value>(&frame).unwrap(),value);
}
