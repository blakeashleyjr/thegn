use std::io::{self, Write};
struct BoundedFrame(Vec<u8>, usize);

impl Write for BoundedFrame {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        if bytes.len() > self.1.saturating_sub(self.0.len()) {
            return Err(io::Error::other("resident frame exceeds byte limit"));
        }
        // Vec's geometric growth must not exceed the explicit allocation cap.
        let needed = self.0.len() + bytes.len();
        if needed > self.0.capacity() {
            let capacity = needed
                .max(self.0.capacity().saturating_mul(2))
                .min(self.1 + 1);
            self.0.reserve_exact(capacity - self.0.len());
        }
        self.0.extend_from_slice(bytes);
        Ok(bytes.len())
    }
    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

fn main() {
 const LIMIT: usize = 1024*1024;
 for n in 300000..300150 {
  let value=serde_json::json!({"id":1000000,"method":"provider.call","params":{"a":"x".repeat(300000),"b":"y".repeat(n)}});
  let mut frame=BoundedFrame(Vec::new(),LIMIT-1);
  serde_json::to_writer(&mut frame,&value).unwrap();
  if frame.0.len()==frame.0.capacity() && frame.0.capacity()>LIMIT/2 {
   let before=frame.0.capacity();frame.0.push(b'\n');
   println!("second_len={n} wire_len={} before_capacity={before} after_capacity={} max={LIMIT}",frame.0.len(),frame.0.capacity());return;
  }
 }
 println!("No boundary found in fixture range");
}
