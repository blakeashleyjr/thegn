include!("/tmp/thegn-audit-maintenance-protocols-20260913/crates/thegn-svc/src/plugin/platform/unix.rs");
#[test]
fn diagnostic_signal_notice() {
 let runtime=tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap();
 let enter=runtime.enter(); let mut cmd=std::process::Command::new("sh");
 cmd.args(["-c","sleep 0.05; exit 7"]).stdin(std::process::Stdio::piped()).stdout(std::process::Stdio::piped()).stderr(std::process::Stdio::piped());
 let mut process=Prepared::new().unwrap().spawn(cmd).unwrap();drop(enter);
 runtime.block_on(async {
   let result=tokio::time::timeout(std::time::Duration::from_secs(1), process.leader.wait_ready()).await;
   eprintln!("notice={:?} exited={:?}", result, process.leader.exited_without_reaping());
   eprintln!("reap={:?}", process.leader.reap());
 });
}

#[test]
fn diagnostic_direct_signal() {
 let runtime=tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap();
 runtime.block_on(async {
   let mut signals=tokio::signal::unix::signal(tokio::signal::unix::SignalKind::child()).unwrap();
   let mut child=std::process::Command::new("sh").args(["-c","sleep 0.05; exit 7"]).spawn().unwrap();
   eprintln!("direct notice={:?}",tokio::time::timeout(std::time::Duration::from_secs(1),signals.recv()).await);
   eprintln!("wait={:?}",child.wait());
 });
}
